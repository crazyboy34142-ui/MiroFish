APK kaise banayein (5 min, free):
1. github.com par naya repo banao (Public ya Private).
2. Is zip ke andar ki saari files (hidden .github folder samet) repo mein upload karo.
3. Repo -> Actions tab -> "Build APK" -> Run workflow.
4. 3-5 min baad run khulo -> neeche Artifacts -> FlagsWarArena-apk download karo.
5. Zip khol ke app-debug.apk phone mein install karo (Unknown sources allow karna padega).
